import { Component } from '@angular/core';

@Component({
  selector: 'app-projectdetails',
  imports: [],
  templateUrl: './projectdetails.component.html',
  styleUrl: './projectdetails.component.scss'
})
export class ProjectdetailsComponent {

}
