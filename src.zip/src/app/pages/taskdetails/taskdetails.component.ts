import { Component } from '@angular/core';

@Component({
  selector: 'app-taskdetails',
  imports: [],
  templateUrl: './taskdetails.component.html',
  styleUrl: './taskdetails.component.scss'
})
export class TaskdetailsComponent {

}
